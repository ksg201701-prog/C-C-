#include <stdio.h>

#define MAX 50

void bubbleSort(int *arr, int n) {
    int i, j, temp;

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (*(arr + j) > *(arr + j + 1)) {
                temp = *(arr + j);
                *(arr + j) = *(arr + j + 1);
                *(arr + j + 1) = temp;
            }
        }
    }
}

int main(void) {
    int score[MAX];
    int *ptr = score;
    int n, i;

    printf("학생 수를 입력하세요 (1~50): ");
    scanf("%d", &n);

    if (n < 1 || n > MAX) {
        printf("오류: 학생 수는 1명 이상 50명 이하여야 합니다.\n");
        return 1;
    }

    for (i = 0; i < n; i++) {
        printf("%d번째 학생의 성적을 입력하세요: ", i + 1);
        scanf("%d", ptr + i);
    }

    bubbleSort(ptr, n);

    printf("\n정렬된 성적: ");
    for (i = 0; i < n; i++) {
        printf("%d ", *(ptr + i));
    }

    printf("\n최고 성적: %d", *(ptr + n - 1));
    printf("\n최하 성적: %d\n", *ptr);

    return 0;
}